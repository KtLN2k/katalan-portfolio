// Change color when sliders move
function colors() {
    let red = document.getElementById('red').value;
    let green = document.getElementById('green').value;
    let blue = document.getElementById('blue').value;
    
    let colorText = 'rgb(' + red + ',' + green + ',' + blue + ')';
    
    document.getElementById('output').innerHTML = colorText;
    document.body.style.background = colorText;
}

// Save color button
document.getElementById('saveColor').onclick = function() {
    let color = document.getElementById('output').innerHTML;
    let savedColors = JSON.parse(localStorage.getItem('myColors') || '[]');
    
    if (savedColors.indexOf(color) === -1) {
        savedColors.push(color);
        localStorage.setItem('myColors', JSON.stringify(savedColors));
        showSavedColors();
        alert('צבע נשמר!');
    } else {
        alert('צבע כבר קיים!');
    }
};

// Show saved colors
function showSavedColors() {
    let savedColors = JSON.parse(localStorage.getItem('myColors') || '[]');
    let colorList = document.getElementById('savedColors');
    
    colorList.innerHTML = '';
    
    savedColors.forEach(function(color) {
        let colorDiv = document.createElement('div');
        colorDiv.className = 'saved-color-item';
        colorDiv.innerHTML = '<div style="background-color:' + color + '"></div><span>' + color + '</span>';
        
        colorDiv.onclick = function() {
            let rgb = color.match(/\d+/g);
            document.getElementById('red').value = rgb[0];
            document.getElementById('green').value = rgb[1];
            document.getElementById('blue').value = rgb[2];
            colors();
        };
        
        colorList.appendChild(colorDiv);
    });
}

// Menu buttons
document.getElementById('homeBtn').onclick = function() {
    location.reload();
};

document.getElementById('updatesBtn').onclick = function() {
    alert('עדכונים: שמירת צבעים, רקע דינמי');
};

document.getElementById('aboutBtn').onclick = function() {
    alert('נבנה על ידי בן קטלן');
};

// Show saved colors when page loads
showSavedColors();